rnorm(10)
x <- list("I'm a list!")
suppressPackageStartupMessages(library(ggplot2))
qplot(mpg, wt, data = mtcars)
