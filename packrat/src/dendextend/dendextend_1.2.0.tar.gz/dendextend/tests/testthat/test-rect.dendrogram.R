# library(testthat)
# 
# context("rect.dendrogram")
# 
# test_that("rect.dendrogram work",{
#    
# #    dend15 <- c(1:5) %>% dist %>% hclust(method = "average") %>% as.dendrogram
# #    # dend15 <- c(1:25) %>% dist %>% hclust(method = "average") %>% as.dendrogram
# #    dend15 %>% set("branches_k_color") %>% plot
# #    dend15 %>% rect.dendrogram(k=3, 
# #                               border = 8, lty = 5, lwd = 2)
# 
#    
#    # expect_equal(attr(fixed_dend, "members"), 5)
# })
# 
# 
# 


# #### this throws an error
#    dend15 <- c(1:5) %>% dist %>% hclust(method = "average") %>% as.dendrogram
#    # dend15 <- c(1:25) %>% dist %>% hclust(method = "average") %>% as.dendrogram
#    dend15 %>% set("branches_k_color") %>% plot
#    dend15 %>% rect.dendrogram(k=4, 
#                               border = 8, lty = 5, lwd = 2)
