library("testthat")
test_package("TSP")

