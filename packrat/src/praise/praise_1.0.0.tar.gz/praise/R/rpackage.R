
rpackage <- c(
  "code",
  "library (or package?)",
  "package",
  "program",
  "project",
  "software",
  "R package"
)
