library(testthat)
library(praise)

test_check("praise")
