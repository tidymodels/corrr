
# 1.0.3

* Use `xml2::xml_find_first` instead of deprecated `xml2::xml_find_one`
  (Thanks to @jimhester)

# 1.0.2

* Explicit import from base packages

# 1.0.1

* Rewritten using `xml2` and `curl` instead of `XML` and `RCurl`
  (Thanks to @jeroenooms)

# 1.0.0

First released version.
