#' badgecreatr
#' 
#' Create badges in your readme file 
#' with a simple function. Run this once and the badges are created.
#' 
#' @docType package
#' @name badgecreatr
NULL
