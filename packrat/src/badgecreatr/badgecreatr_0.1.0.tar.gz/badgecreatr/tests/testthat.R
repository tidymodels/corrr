# Sys.setenv("R_TESTS" = "")
library(testthat)
library(badgecreatr)

test_check("badgecreatr")
