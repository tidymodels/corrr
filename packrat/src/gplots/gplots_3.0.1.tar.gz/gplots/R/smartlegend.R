# $Id: smartlegend.R 2089 2016-03-24 13:47:48Z warnes $

smartlegend <- function(x=c("left","center","right"),
                        y=c("top","center","bottom"),
                        ..., inset=0.05 )
    .Defunct('legend', 'gplots')


